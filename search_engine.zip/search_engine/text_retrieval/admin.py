from django.contrib import admin

from .models import Document
from .models import Stem

admin.site.register(Document)
admin.site.register(Stem)
# Register your models here.
