from __future__ import unicode_literals

from django.db import models

class Document(models.Model):
    document_content = models.CharField(max_length=2000)

    def _stem_document(self):
        "return stemmed document."
        return '%s' % (self.document_content)

    Stemming = property(_stem_document);

class Stem(models.Model):
    stem_source = models.CharField(max_length=30)
    stem_destination = models.CharField(max_length=30)

class StemmedDocument(models.Model):
    document_content = models.CharField(max_length=2000)